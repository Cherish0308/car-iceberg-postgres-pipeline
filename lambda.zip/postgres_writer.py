"""
PostgresWriter implementation following SRP, OCP, LSP, and DIP.
SRP: Only responsible for Postgres database operations.
OCP: Writer protocol allows new storage backends without modifying this class.
LSP: Can substitute any Writer implementation.
DIP: Depends on SQLAlchemy engine abstraction, can be injected.
"""
from typing import Sequence, Dict, Any

from sqlalchemy import create_engine, text

from config import POSTGRES_URL
from interfaces import Writer


class PostgresWriter(Writer):
    """
    Writes data to Postgres with upsert support.
    Following SRP: Single responsibility of Postgres persistence.
    """

    def __init__(self, engine=None):
        """
        Initialize Postgres writer.
        
        Args:
            engine: SQLAlchemy engine (injectable for testing).
        """
        self._engine = engine or create_engine(POSTGRES_URL)

    def upsert(self, table: str, records: Sequence[Dict[str, Any]]) -> None:
        """
        Upsert records into Postgres table.
        Uses ON CONFLICT for atomic upsert operation.
        
        Args:
            table: Table name to upsert into.
            records: List of records as dictionaries.
        """
        records = list(records)
        if not records:
            return

        cols = records[0].keys()
        col_list = ",".join(cols)
        val_list = ",".join([f":{c}" for c in cols])
        update_list = ",".join([f"{c}=EXCLUDED.{c}" for c in cols if c != "car_id"])

        sql = f"""
        INSERT INTO {table} ({col_list})
        VALUES ({val_list})
        ON CONFLICT (car_id)
        DO UPDATE SET {update_list}
        """

        with self._engine.begin() as conn:
            conn.execute(text(sql), records)